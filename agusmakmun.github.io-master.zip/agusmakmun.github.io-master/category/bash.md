---
layout: posts_by_category
categories: bash
title: Bash
permalink: /category/bash
---